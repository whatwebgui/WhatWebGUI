Invoke-WebRequest -Uri https://wslstorestorage.blob.core.windows.net/wslblob/wsl_update_x64.msi -OutFile wsl_update_x64.msi -UseBasicParsing

Start-Process msiexec -Wait -ArgumentList /q, /i, wsl_update_x64.msi

Remove-Item wsl_update_x64.msi

wsl --set-default-version 2

Invoke-WebRequest -Uri https://aka.ms/wsl-debian-gnulinux -OutFile debian.appx -UseBasicParsing

Add-AppxPackage .\debian.appx

Remove-Item .\debian.appx

explorer.exe shell:appsFolder\TheDebianProject.DebianGNULinux_76v4gfsz19hv4!debian