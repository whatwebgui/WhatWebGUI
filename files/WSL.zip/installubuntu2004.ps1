Invoke-WebRequest -Uri https://wslstorestorage.blob.core.windows.net/wslblob/wsl_update_x64.msi -OutFile wsl_update_x64.msi -UseBasicParsing

Start-Process msiexec -Wait -ArgumentList /q, /i, wsl_update_x64.msi

Remove-Item wsl_update_x64.msi

wsl --set-default-version 2

Invoke-WebRequest -Uri https://aka.ms/wslubuntu2004 -OutFile ubuntu.appx -UseBasicParsing

Add-AppxPackage .\ubuntu.appx

Remove-Item .\ubuntu.appx

explorer.exe shell:appsFolder\CanonicalGroupLimited.Ubuntu20.04onWindows_79rhkp1fndgsc!ubuntu2004
